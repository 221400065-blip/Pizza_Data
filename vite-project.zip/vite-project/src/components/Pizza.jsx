import React from 'react'


export default function Pizza({pizza}) {
  return (
    <div style={{border:2, borderStyle:'solid',marginBottom:'50px', height:'400px', width:'300px',padding:'10px',flex:1, flexDirection:'column'}}>
       <h5 style={{textAlign:'center'}} > {pizza.name}</h5>
        <div style={{flex:3}}>
            <img src={pizza.image} alt='Pizza picture' className='img-fluid'  style={{width:'280px', height:'280px'}}></img>
        </div>
        <div  className='flex-container' style={{flex:2}}>
            <div className='w-100' >
                <select name="" id="">
                    {pizza.varients.map((item,index)=>(
                        <option key={index}  value={item}>{item}</option>
                    ))}
                </select>
            </div>

            {/* <div className='w-100' >
                    <select name="" id="">
                        <option >{pizza.prices[0].small}</option>
                        <option >{pizza.prices[0].medium}</option>
                        <option >{pizza.prices[0].large}</option>

                     </select>
            </div> */}
        </div>
    </div>
  )
}
