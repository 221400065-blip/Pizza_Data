import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.js"
import Navbar from "./components/Navbar"
import HomeScreen from "./screens/HomeScreen"


function App() {

  return (
    <>
      <Navbar/>
      <HomeScreen/>
      
    </>
  )
}

export default App
