import pizzas from '../pizzasdata'
import { useState } from 'react'
import Pizza from '../components/Pizza'

export default function HomeScreen() {
    const[pizzaData,setPizzaData] = useState(pizzas)
  return (
   <>
        <div className='row' style={{padding:'50px'}}>
            
                {pizzaData.map((item,index)=>(
                  <div className='col-md-4'>
                  <Pizza key={index} pizza={item}  />
                  </div>
                ))}
           

        </div>
   </>
  )
}
